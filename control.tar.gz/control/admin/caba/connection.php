<?php
$servername = "localhost";
$username = "root";
$password = "Mariadb&2022";
$dbname = "iamcest_red_infarto_caba";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>