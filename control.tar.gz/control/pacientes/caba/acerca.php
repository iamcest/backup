<?php
include('connection.php');
session_start();
$sqlquery="SELECT (SELECT COUNT(*) FROM patient) as PatientCount, (SELECT COUNT(*) FROM doctor) as doctorCount, (SELECT COUNT(*) FROM employee) as employeeCount, (SELECT COUNT(*) FROM department) as departmentCount";
$result = mysqli_query($conn, $sqlquery); 
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>RED IAMCEST | CABA | SAME | Control General</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
    <div class="main-wrapper">
        <div class="header">
        <div class="header-left"><a href="index.php" class="logo"><img src="assets/img/logo-iamcest.png" width="35" height="35" alt="Logo IAMCEST | Salud Digital" /> <span> PACIENTES</span></a></div>
        <a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
            <ul class="nav user-menu float-right">
                <li class="nav-item dropdown has-arrow">
                    <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img"><img class="rounded-circle" src="assets/img/user.jpg" width="24" alt="Admin"><span class="status online"></span></span>
			<span><?php echo $_SESSION['username'];?></span></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="userprofile.php">Mi Perfil</a>
						<a class="dropdown-item" href="logout.php">Salir</a>
					</div>
                </li>
            </ul>
            <div class="dropdown mobile-user-menu float-right">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="userprofile.php">Mi Perfil</a>
                    <a class="dropdown-item" href="logout.php">Salir</a>
                </div>
            </div>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Principal</li>
                        <li class="active">
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
<!--                        <li>
                            <a href="hospitales.php"><i class="fa fa-hospital-o"></i> <span>Hospitales</span></a>
                        </li>
                        <li>
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li>
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <li>
                            <a href="colaboradores.php"><i class="fa fa-user-circle"></i> <span>Colaboradores</span></a>
                        </li>-->
                        <li>
                            <a href="turnos.php"><i class="fa fa-calendar"></i> <span>Turnos</span></a>
                        </li>
                        <!--<li>
                            <a href="agenda.php"><i class="fa fa-calendar-check-o"></i> <span>Agenda</span></a>
                        </li>-->
                        <li>
                        <a href="acerca.php"><i class="fa fa-heart-o"></i><span>Acerca de</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                        <span class="dash-widget-bg1"><i class="fa fa-user-md" aria-hidden="true"></i></span>
                        <div class="dash-widget-info text-right">
                        <h3><?php echo $row['doctorCount'];?></h3>
                        <span class="widget-title1">Profesionales <i class="fa fa-check" aria-hidden="true"></i></span>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg2"><i class="fa fa-user-o"></i></span>
                            <div class="dash-widget-info text-right">
                                <h3><?php echo $row['PatientCount'];?></h3>
                                <span class="widget-title2">Pacientes <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg3"><i class="fa fa-user-circle" aria-hidden="true"></i></span>
                            <div class="dash-widget-info text-right">
                                <h3><?php echo $row['employeeCount'];?></h3>
                                <span class="widget-title3">Colaboradores <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg4"><i class="fa fa-hospital-o" aria-hidden="true"></i></span>
                            <div class="dash-widget-info text-right">
                                <h3><?php echo $row['departmentCount'];?></h3>
                                <span class="widget-title4">Hospitales <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
<div class="row">
<div class="col-12 col-md-6 col-lg-8 col-xl-8">
<div class="card">
<div class="card-header">
<h4 class="card-title d-inline-block">Anexo <a href="https://documentosboletinoficial.buenosaires.gob.ar/publico/PE-RES-MSGC-MSGC-2860-19-ANX.pdf">Descargar Pdf</a></h4>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 col-xl-4">
<div class="card member-panel">
<div class="card-header bg-white"><h4 class="card-title mb-0">Protocolo Infarto Buenos Aires</h4></div>
</div>
</div>
<h4>NORMATIVA DEL TRATAMIENTO DEL SINDROME CORONARIO AGUDO CON
SUPRADESNIVEL DEL SEGMENTO ST EN PACIENTES INGRESADOS EN
HOSPITALES DE LA CIUDAD AUTONOMA DE BUENOS AIRES. (SCACEST)</h4>
<br />
<h5>ÍNDICE</h5>
<p>
1.- Introducción<br />
2.- Objetivo<br />
3.- Descripción del Protocolo INFARTO BUENOS AIRES de la Red de Hemodinamia de la Ciudad Autónoma de Buenos Aires<br />
4.- Ingreso y recepción del paciente al Hospital<br />
4.1.- Pacientes que consultan espontáneamente a la guardia del Hospital<br />
4.2.- Pacientes que ingresan en ambulancia<br />
5.- Contacto entre el médico receptor del paciente y el Servicio de Hemodinamia<br />
5.1.- Hospitales con Servicio de Hemodinamia<br />
5.2.- Hospitales sin servicio de Hemodinamia<br />
6.- Traslado del paciente entre Hospitales<br />
6.1.- Pacientes sin requerimientos de asistencia respiratoria mecánica<br />
6.2.- Pacientes con requerimientos de asistencia respiratoria mecánica<br />
7.- Realización de la angioplastia<br />
8.- Internación post angioplastia<br />
9.- Anexo<br />
</p><br />
<h5>1.- INTRODUCCIÓN:</h5>
<p>Las enfermedades cardiovasculares constituyen una de las principales causas de muerte en Argentina. Según datos del Ministerio de Salud de la Nación, en el año 2011, se
produjeron 236 muertes cada 100.000 habitantes. Se estima que se producen anualmente en nuestro país entre 40.000 y 50.000 infartos, y que este valor podría estar
subestimado ya que muchos pacientes no son diagnosticados o fallecen antes de acudir al hospital. Por otra parte el acceso a la reperfusión en los tiempos recomendados se
logra en menos de la mitad de los pacientes.</p><br />
<p>En aquellos Sistemas de Salud que utilizan la angioplastia primaria como estrategia principal de reperfusión, resulta esencial la velocidad con que se realiza la misma. Se
aconseja que el tiempo puerta- balón no exceda los 60 minutos en hospitales con disponibilidad de laboratorio de Hemodinamia, y 120 minutos en pacientes derivados
de centros sin laboratorio de Hemodinamia.</p><br />
<p>Debido a que en la demora a la reperfusión coronaria, intervienen diferentes factores (inherentes al paciente, a los Servicios de Atención pre-hospitalaria y correspondientes
a las Instituciones Asistenciales, entre otras), es primordial realizar un trabajo multidisciplinario coordinado, con el fin de lograr un sistema eficiente que brinde a los
pacientes con Síndrome coronario agudo con elevación del segmento ST (SCACEST) un mayor acceso con una rápida implementación terapéutica.</p><br />
<p>Para aumentar el número de pacientes que accedan en tiempo adecuado a la reperfusión, es necesaria la confección de protocolos que coordinen en forma adecuada
a los efectores del Sistema de Salud.</p><br />
<p>Este es el fundamento por el cual la (Red de Hemodinamia elabora el protocolo INFARTO BUENOS AIRES destinado a ordenar y homogeneizar las actividades realizadas por todos los <b>hospitales del GCABA y el Sistema de Emergencia (SAME)</b> en
la atención de pacientes con SCACEST.</p><br />
<h5>2.- OBJETIVO</h5>
<p>Implementar los medios dentro del sistema de salud de la CABA para la atención del Infarto Agudo de Miocardio (IAM), como en los países del primer mundo; logrando de
esta forma acceder mediante una acción en Red, a la realización del SCACEST en los tiempos de ventana adecuados para disminuir la morbimortalidad del infarto en CABA.</p>
<h5>3.- LA RED INFARTO BUENOS AIRES</h5>
<p>La Red de Hemodinamia y el presente Protocolo INFARTO BUENOS AIRES está conformado por todos los hospitales del GCABA, con y sin disponibilidad de
laboratorio de Hemodinamia y el SAME.</p><br />
<p>Sus objetivos son implementar la angioplastia primaria como estrategia principal de repercusión y utilizar protocolos de actuación común y monitoreo de la calidad de
atención.</p>
<p>Los hospitales actualmente con capacidad para angioplastia primaria 24 hs los 365 días del año son:<br /><br />
- Hospital General de Agudos Dr. Cosme Argerich<br />
- Hospital Donación Francisco Santojanni<br />
- Hospital General de Agudos Dr. Juan A. Fernández<br />
- Hospital General de Agudos Carlos G. Durand.<br />
Actualmente los hospitales General de Agudos Bernardino Rivadavia y General de Agudos José María Ramos Mejía están en proceso de organización para atención fuera
de horarios de planta.</p><br />
<h5>4.- INGRESO y RECEPCIÓN DEL PACIENTE AL HOSPITAL</h5>
<p><b>4.1- Pacientes que consultan espontáneamente a la guardia del Hospital</b></p><br />
<p>El paciente con dolor precordial que consulta en forma espontánea al Servicio de Emergencias debe ser jerarquizado como de ALTO RIESGO, por lo que es muy
importante su detección inmediata. El personal administrativo y de seguridad capacitado previamente será el encargado de priorizar rápidamente el contacto de estos
pacientes con el personal médico (Triage) del Servicio de Emergencias para la realización de un electrocardiograma (ECG) dentro de los 10 minutos del ingreso, que
confirme o descarte el SCACEST.</p>
<p>Se instalarán en los Servicios de Emergencia canales informativos (paneles, cartelería, etc.) que orienten a los pacientes sobre la prioridad en la atención, informando que no
deben esperar el turno asignado, ya que esto puede generar demoras con impactos importantes en la morbi-mortalidad.</p><br />
<p>En las guardias habrá personal profesional médico y no médico entrenado en la evaluación inicial de estos pacientes, en la interpretación del ECG inicial para activar
inmediatamente el sistema en caso de que se trate de SCACEST.</p><br />
<p>En situaciones de duda diagnóstica, los profesionales médicos de las diferentes guardias cuentan con la posibilidad de interconsultar con los hemodinamistas de guardia. La
interconsulta podrá efectuarse mediante el envío de imágenes a través de los teléfonos inteligentes.</p><br />
Una vez realizado el electrocardiograma y confirmado el diagnóstico se gestionará la solicitud de Hemodinamia de urgencia (activación del Código Infarto) mediante la
coordinación del SAME (hospitales sin disponibilidad de Laboratorio de Hemodinamia)</p><br />
<p>El paciente deberá ser trasladado directamente a la sala de hemodinamia en el menor tiempo posible evitando traslado a otras áreas de diagnóstico o cuidados intensivos. El
tiempo puerta-balón de estos pacientes no debería superar los 60 minutos en el caso del ingreso directo a hospitales con disponibilidad de hemodinamia y no mayor a 120
minutos en el caso de pacientes derivados de otros centros.</p></br />
<p>Los Servicios de Emergencias de cada hospital evaluaran periódicamente las demoras de tiempo entre la consulta, la realización del electrocardiograma y el diagnóstico de
SCACEST, con el fin de lograr que dicho periodo de tiempo no exceda los 10 minutos. Para lograr este objetivo debe haber una acción coordinada entre el Servicio de
Cardiología y el Servicio de Emergencias del hospital, y dicha demora debe ser parámetro de buen funcionamiento del mismo (indicador de calidad)
<p><b>4.2.- Pacientes que ingresan en ambulancia.</b></p><br />
<p>Los pacientes ingresados por dolor precordial deberán tener prioridad. Ingresarán a un sector de la Guardia destinado al rápido diagnóstico de SCACEST para la realización
inmediata de un ECG. Dicho electrocardiograma deberá ser evaluado por algún personal profesional médico con capacidad de hacer diagnóstico de SCACEST en un
periodo no mayor a los 10 minutos. Para aquellos centros que no cuentan con Servicio de Hemodinamia, luego de gestionar la hemodinamia de urgencia se utilizará para el
traslado del paciente la ambulancia de auxilio del centro con autorización de la Coordinación del SAME para minimizar los tiempos de traslado.</p><br />
<p>Con el fin de disminuir aún más la demora en la activación del sistema se realizará un registro electrocardiográfico en el domicilio del paciente y se activará el código de infarto en forma precoz desde la ambulancia si así correspondiere.</p><br />
<h5>5.- CONTACTO ENTRE EL MÉDICO RECEPTOR DEL PACIENTE Y EL SERVICIO DE HEMODINAMIA</h5>
<p><b>5.1.- Hospitales con Hemodinamia</b></p><br />
<p>Los hospitales que cuentan con Servicio de Hemodinamia realizaran el diagnóstico precoz. Los cardiólogos responsables de la realización del diagnóstico y los
intervencionistas van a interactuar en forma estrecha y con un protocolo de acción coordinado con el fin de optimizar el flujo de pacientes dentro del hospital y de esa
manera evitar demoras innecesarias en el tiempo a la reperfusión.</p><br />
<p><b>5.2- Hospitales sin Hemodinamia</b></p><br />
<p>Una vez realizado el diagnóstico de SCACEST, el hospital solicitante deberá comunicarse a la brevedad con la coordinación del SAME a fin de organizar el traslado
del paciente. El Médico Coordinador de SAME, a su vez debe contactarse telefónicamente con los médicos Hemodinamistas de guardia disponibles del día de
cada hospital.</p><br />
<h5>6.- TRASLADO DEL PACIENTE DE HOSPITAL SIN HEMODINAMIA A HOSPITAL CON DICHA PRESTACIÓN</h5>
<p>El inicio del traslado deberá ser inmediato con el fin de lograr la reperfusión dentro de los 120 minutos. En caso de demora mayor, de no haber contraindicaciones, deberá
administrarse, tratamiento fibrinolítico e ingresar al paciente según su evolución en protocolo a angioplastia farmacoinvasiva o rescate en caso de reperfusión fallida.</p><br />
<p><b>6.1.- Pacientes sin requerimientos de asistencia respiratoria mecánica.</b></p><br />
<p>La reperfusión de la arteria responsable del infarto es prioridad ya que esto ha demostrado reducir la morbilidad y mortalidad de este grupo de pacientes. En pacientes
con SCACEST que se presentan sin requerimientos de asistencia respiratoria mecánica (ARM), con el fin de reducir los tiempos de la reperfusión, y teniendo en cuenta que la
demora entre centros generalmente no es superior a 40 minutos, el traslado de los pacientes deberá realizarse con la ambulancia del centro derivador, ya que las mismas
cuentan con desfibrilador, y el tiempo de traslado con este tipo de ambulancia se disminuye significativamente.</p>
<p>No se ha visto en pacientes trasladados con este tipo de ambulancia un aumento de las complicaciones. Por el contrario, está demostrado que toda medida que disminuya el
tiempo a la permeabilización de la arteria responsable del IAM mejorará el pronóstico del paciente considerando que estos pacientes deben trasladarse inmediatamente al
centro con disponibilidad de hemodinamia para angioplastia de urgencia para luego retornar al centro derivador o permanecer en el hospital de derivación en caso de
presentar cama en Unidad Coronaria (UCO) o Unidad Coronaria Móvil (UCOM) disponible.</p><br />
<p><b>6.2.- Pacientes con requerimientos de asistencia respiratoria mecánica</b></p><br />
<p>En caso de que estos pacientes estén en condiciones de ser trasladados, el traslado entre centros se realizará con la Unidad Coronaria Móvil disponible más cercana a la
localización del paciente. Para este grupo de pacientes se aconseja la derivación a un Servicio de Hemodinamia con disponibilidad de balón de contrapulsación intraaortica.
Será una condición indispensable de aceptación contar con disponibilidad de cama en Unidad Coronaria o en Shock Room con respirador para la posterior internación del
paciente en el centro receptor.</p><br />
<p>La decisión del traslado será consensuada entre la coordinación del SAME, el Médico derivador y el Médico intervencionista receptor.</p><br />
<h5>7.- REALIZACIÓN DE LA ANGIOPLASTIA</h5>
<p>Una vez que el paciente ingresa al Servicio de Hemodinamia, es prioritaria la rápida realización del estudio diagnóstico y posterior reperfusión del paciente. Como el
SCACEST constituye una emergencia médica, este tipo de pacientes tiene prioridad por sobre aquellos que están con turnos programados. Se aconseja dejar el quirófano libre
una vez que se solicitó la derivación de un paciente con esta patología.</p><br />
<p>Se sugiere a su vez, previo a la llegada del paciente, la preparación del quirófano con los materiales necesarios para el tratamiento del IAM con el fin de disminuir los
tiempos a la reperfusión. Los Servicios de Hemodinamia deberán mantener estándares universales de tiempo de demora a la angioplastia con evaluación periódica de los
mismos. En aquellos casos en los que no se cuenta con disponibilidad de camas en el hospital con Servicio de Hemodinamia, el médico intervencionista utilizará la vía radial
como primera opción, con el fin de retirar el introductor una vez finalizado el procedimiento y retornar al paciente al centro derivador.</p><br />
<h5>8.- INTERNACIÓN POST ANGIOPLASTIA</h5>
<p>El objetivo del tratamiento del SCACEST es la rápida reperfusión del paciente. El cumplimiento de este objetivo en cada paciente permite disminuir el área de necrosis
miocárdica y así aumentar la sobrevida. Con el fin de cumplir el objetivo de reperfusión con celeridad es importante no perder tiempo en ninguno de los pasos que lleven a la
exitosa reperfusión del paciente.</p><br />
<p>Un escenario repetido en el que la reperfusión no se logra responde a la falta de disponibilidad de camas de internación en un Hospital con Servicio de Hermodinamia.
Por tanto tiene como consecuencia la falta de reperfusión en un Hospital sin Servicio de Hemodinamia. Así entonces, a efecto de evitar tal escenario resulta prudente que en los
supuestos de infartos no complicados se proceda a la rápida reperfusión del paciente, independientemente de la disponibilidad o no de camas en el Hospital con Servicio de
Hermodinamia, y el posterior retorno del paciente al centro derivador en caso de no existir disponibilidad en aquel efector donde fue reperfundido. De esta manera se
garantiza la reperfusión del paciente disminuyendo el riesgo a corto y largo plazo.</p><br />
<p>Así entonces, en pacientes con SCACEST no complicados (pacientes sin inotrópicos ni otro método de asistencia y paciente no anticoagulado con anticoagulantes orales) el
mayor esfuerzo inicial debería estar orientado hacia la reperfusión del paciente en el menor tiempo posible (rápido diagnóstico y contacto con servicio de hemodinamia,
traslado en ambulancia de centro derivador y angioplastia) internándose el paciente luego de la angioplastia en el hospital con Servicio de Hemodinamia en caso de existir
disponibilidad de camas en Unidad Coronaria.</p>
<p>En caso contrario, el paciente retornará al hospital derivador activándose para tal fin la U.C.M o aquel móvil que decida la Coordinación Médica.</p><br />
<p>Se mantendrá una estrecha relación entre la coordinación del SAME, el Médico Intervencionista y el Médico Interno del hospital con el fin de optimizar el flujo de
pacientes. El retorno del paciente al hospital derivador encuentra aval en un registro de pacientes con SCACEST realizado en Buenos Aires, donde no se constataron
diferencias significativas en la evolución entre los pacientes que permanecieron en el hospital donde se realizó la angioplastia respecto de aquellos que fueron retornados
inmediatamente después de la misma al hospital de origen.</p><br />
<p>En aquellos casos en los que no se cuenta con disponibilidad de camas en el hospital con Servicio de Hemodinamia, el Médico Intervencionista utilizará la vía radial como
primera opción, con el fin de retirar el introductor una vez finalizado el procedimiento. En caso de no poder realizar el procedimiento por dicha vía, el médico intervencionista
deberá evaluar la posibilidad de retirar el introductor femoral una vez finalizada la angioplastia ya sea revirtiendo la heparina utilizada con protamina, con una compresión
más prolongada o con sistemas de oclusión, con el fin de disminuir el riesgo del retorno del paciente.</p><br />
<p>En aquellos pacientes con SCACEST complicados es de importancia coordinar la disponibilidad de camas en el hospital con Servicio de Hemodinamia con el fin de que,
una vez realizada la angioplastia, el paciente quede internado en dicho hospital. En este tipo de pacientes es prioritario disponer de cama en el Centro donde se realizará la
angioplastia, por lo que el Médico Coordinador del SAME consultará, de ser necesario, a todos los centros con disponibilidad de Hemodinamia para priorizar la derivación.</p><br />
<p>Si durante el traslado o la angioplastia, un paciente con IAM no complicado pasara a tener algún criterio de IAM complicado, se procederá a su internación en un Hospital
con Servicio de Hermodinamia. . En caso de dificultad con la disponibilidad de camas se considerará la posibilidad de trasladar a algún paciente de menor riesgo entre
hospitales, con el fin de generar la cama para el paciente en cuestión. En caso contrario deberá quedar en el hospital determinando el médico interno en conjunto con el hemodinamista el área de internación.
</p>
</div>
</div>
</div>
<p>

</div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/Chart.bundle.js"></script>
    <script src="assets/js/chart.js"></script>
    <script src="assets/js/app.js"></script>

</body>
</html>
