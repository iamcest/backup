<?php 
include("connection.php");
session_start();
if (isset($_POST['submit'])) {
    $docDept=$_POST['department'];
    $docName=$_POST['doctorName'];
    //$availDays=$_POST['availDays'];
	$availDays=implode(',', $_POST['availDays']);
    $startTime=$_POST['startTime'];
    $endTime=$_POST['endTime'];
    $status=$_POST['status'];
    $SuccMessage="Agenda cargada correctamente!";
	
$sql = "INSERT INTO doctor_schedule (department_name,doctorName,availDays,startTime,endTime,status) VALUES ('$docDept','$docName','$availDays','$startTime','$endTime','$status')";

if ($conn->query($sql)) {
    echo  "<script type='text/javascript'>alert('$SuccMessage');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>RED IAMCEST | CABA | SAME | AGREGAR AGENDA</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
    <div class="main-wrapper">
        <div class="header">
			<div class="header-left">
				<a href="index.php" class="logo">
					<img src="assets/img/logo-iamcest.png" width="35" height="35" alt=""> <span>GCABA | SAME</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Principal</li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                        <li>
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li>
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <li class="active">
                            <a href="agenda.php"><i class="fa fa-calendar"></i> <span>Agenda</span></a>
                        </li>
                        <li>
                            <a href="acerca.php"><i class="fa fa-hospital-o"></i> <span>Acerca</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Agregar Agenda</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form method="post">
                            <div class="row">
				<div class="col-md-6">
                                    <div class="form-group">
										<label>Hospital</label>
										<select class="select" name="department">
											<!--<option>Select</option>
											<option>Doctor Name 1</option>
											<option>Doctor Name 2</option>-->
											<option value="department_name">seleccione</option>
 <?php  
									  $sql = "SELECT  department_name FROM department;";  
 									$result = mysqli_query($conn, $sql); 
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          
                               <option value="<?php echo $row["department_name"];?>"><?php echo $row["department_name"];?></option>"
                               
                           
                          <?php  
                          }  
                          ?>
										</select>
									</div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
										<label>Profesional</label>
										<select class="select" name="doctorName">
											<!--<option>Select</option>
											<option>Doctor Name 1</option>
											<option>Doctor Name 2</option>-->
											<option value="doctor_name">seleccione</option>
 <?php  
									  $sql = "SELECT doctor_name FROM doctor;";  
 									$result = mysqli_query($conn, $sql); 
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          
                               <option value="<?php echo $row["doctor_name"];?>"><?php echo $row["doctor_name"];?></option>"
                               
                           
                          <?php  
                          }  
                          ?>
										</select>
									</div>
                                </div>
                                <div class="col-md-6">
									<div class="form-group">
										<label>Fechas disponibles</label>
										<select class="select" multiple="multiple" name="availDays[]">
											<option>Seleccione día</option>
											<option>Domingo</option>
											<option>Lunes</option>
											<option>Martes</option>
											<option>Miércoles</option>
											<option>Jueves</option>
											<option>Viernes</option>
											<option>Sábados</option>
										</select>
									</div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Hora Inicio</label>
                                        <div class="time-icon">
                                            <input type="text" class="form-control" id="datetimepicker3" name="startTime">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Hora Finalización</label>
                                        <div class="time-icon">
                                            <input type="text" class="form-control" id="datetimepicker4" name="endTime">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="form-group">
                                <label>Mensaje (Hasta 100 caracteres)</label>
                                <textarea cols="30" rows="4" class="form-control"></textarea>
                            </div>-->
                            <div class="form-group">
                                <label class="display-block">Estado de la Agenda</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_active" value="Active" >
									<label class="form-check-label" for="product_active">
									Activo
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_inactive" value="Inactive">
									<label class="form-check-label" for="product_inactive">
									Inactivo
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn" name="submit">Agregar Agenda</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
	<script>
            $(function () {
                $('#datetimepicker3').datetimepicker({
                    format: 'LT'
                });
				$('#datetimepicker4').datetimepicker({
                    format: 'LT'
                });
            });
     </script>
</body>
</html>
