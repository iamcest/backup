<?php 
include('connection.php');
if (isset($_POST['submit'])) {
    $target_dir = __DIR__ ."Images/";
    $patientDni=$_POST['patientdni'];
    $patientName=$_POST['patientname'];
    $consultingDoc=$_POST['consultingDoc'];
    $userName=$_POST['userName'];
    $userMail=$_POST['email'];
    $userpass=$_POST['password'];
    $userDob=$_POST['dateofbirth'];
    $usergender=$_POST['gender'];
    $userAddrss=$_POST['address'];
    $userCity=$_POST['city'];
    $userState=$_POST['State'];
    $userPostCode=$_POST['PostalCode'];
    $userPhone=$_POST['phone'];
    $userPic=$_FILES['UserImg']['name'];
    $userStatus=$_POST['status'];
    $SuccMessage="Paciente cargado Correctamente!";
$sql = "INSERT INTO patient (patientdni,patient_name,consultingDoctor,username,email,pssword,dateOfBirth,gender,addrss,city,province,postalCode,phone,UserPic,patientStatus) 
VALUES ('$patientDni','$patientName','$consultingDoc','$userName','$userMail','$userpass','$userDob','$usergender','$userAddrss','$userCity','$userState','$userPostCode','$userPhone','$userPic','$userStatus')";

if ($conn->query($sql)) {
    move_uploaded_file($_FILES['UserImg']['tmp_name'],"Images/".$userPic);
    echo "<script type='text/javascript'>alert('$SuccMessage');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>RED IAMCEST | CABA | SAME | CARGAR PACIENTES</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
    <![endif]-->
    <!-- Number vallidation -->
    <script>
        
   function ValidateUSPhoneNumber() {
  var regExp = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}/;
  var phone = phoneNumber.match(regExp);
       var userPhone ="<?php echo $userPhone ?>";
  if (phone) {
    alert('yes');
    return true;
  }
  alert('no');
  return false;
}
    </script>
   </head>

<body>
    <div class="main-wrapper">
        <div class="header">
			<div class="header-left">
				<a href="index.php" class="logo">
					<img src="assets/img/logo-iamcest.png" width="35" height="35" alt=""> <span>GCABA | SAME</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
            <ul class="nav user-menu float-right">
                <li class="nav-item dropdown has-arrow">
                    <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img"><img class="rounded-circle" src="assets/img/user.jpg" width="40" alt="Admin">
			<span class="status online"></span></span>
                        <span>Admin</span>
                    </a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="docprofile.php">Mi Perfil</a>
						<a class="dropdown-item" href="logout.php">Salir</a>
					</div>
                </li>
            </ul>
            <div class="dropdown mobile-user-menu float-right">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="docprofile.php">Mi Perfil</a>
                    <a class="dropdown-item" href="logout.php">Salir</a>
                </div>
            </div>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Principal</li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                        <li>
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li class="active">
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <li>
                            <a href="agenda.php"><i class="fa fa-calendar"></i> <span>Agenda</span></a>
                        </li>
                        <li>
                            <a href="acerca.php"><i class="fa fa-heart-o"></i> <span>Acerca</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Agregar Paciente</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form id="myForm" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>DNI Paciente<span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="patientdni" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Nombre Paciente<span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="patientname" required>
                                    </div>
                                </div>
                                
                                
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Médico Asignado</label>
                                        <input class="form-control" type="text" name="consultingDoc"required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Usuario <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="userName"required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email <span class="text-danger">*</span></label>
                                        <input class="form-control" type="email" name="email" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Contraseña</label>
                                        <input class="form-control" type="password" name="password" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Repetir Contraseña</label>
                                        <input class="form-control" type="password">
                                    </div>
                                </div>
				<div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Nacimiento</label>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control datetimepicker" name="dateofbirth" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group gender-select">
										<label class="gen-label">Sexo:</label>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" name="gender" class="form-check-input" value="Male" required>Masculino</label>
										</div>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" name="gender" class="form-check-input" value="Female" required>Femenino</label>
										</div>
									</div>
                                </div>
								<div class="col-sm-12">
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Dirección</label>
												<input type="text" class="form-control " name="address" required>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>País</label>
												<select class="form-control select">
													<option>Argentina</option>
													<option>Bolivia</option>
													<option>Chile</option>
													<option>Colombia</option>
													<option>Paraguay</option>
													<option>Perú</option>
													
												</select>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>Ciudad</label>
												<input type="text" class="form-control" name="city" required>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>Estado/Provincia</label>
												<input type="text" name="State" id="State"  class="form-control" required>
											</div>
										</div>
										<div class="col-sm-6 col-md-6 col-lg-3">
											<div class="form-group">
												<label>Código Postal</label>
												<input type="number" class="form-control" name="PostalCode" id="PostalCode" required placeholder="Solo números">
											</div>
										</div>
									</div>
								</div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Celular (10 digitos)</label>
                                        <input class="form-control" type="number" id="phone" name="phone" required placeholder="Solo númersos">
                                    </div>
                                </div>
                                <div class="col-sm-6">
									<div class="form-group">
										<label>Avatar</label>
										<div class="profile-upload">
											<div class="upload-img">
												<img alt="" src="assets/img/user.jpg">
											</div>
											<div class="upload-input">
												<input type="file" class="form-control" name="UserImg" required>
											</div>
										</div>
									</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="display-block">Estado</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="patient_active" value="Active" required>
									<label class="form-check-label" for="patient_active">
									Active
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="patient_inactive" value="Inactive" required>
									<label class="form-check-label" for="patient_inactive">
									Inactive
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn" name="submit">Cargar paciente </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
