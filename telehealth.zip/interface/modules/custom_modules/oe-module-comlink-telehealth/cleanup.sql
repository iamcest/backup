-- This is just a helper script to be used with testing for dropping all the tables that are currently used.
DROP TABLE IF EXISTS `comlink_tele_provider_auth`;
