<?php

/**
 * Handles all of the Provider Calendar events and actions
 *
 * @package openemr
 * @link      http://www.open-emr.org
 * @author    Stephen Nielson <stephen@nielson.org>
 * @copyright Copyright (c) 2021 Comlink
 * @license   https://github.com/openemr/openemr/blob/master/LICENSE GNU General Public License 3
 */

namespace Comlink\OpenEMR\Modules\TeleHealthModule;

use OpenEMR\Common\Logging\SystemLogger;
use OpenEMR\Events\Appointments\AppointmentRenderEvent;
use OpenEMR\Events\Appointments\CalendarUserGetEventsFilter;
use OpenEMR\Events\Core\ScriptFilterEvent;
use OpenEMR\Events\Core\StyleFilterEvent;
use OpenEMR\Services\AppointmentService;
use Symfony\Component\EventDispatcher\EventDispatcher;

class TeleHealthCalendarController
{
    private $logger;
    private $assetPath;
    /**
     * @var The database record if of the currently logged in user
     */
    private $loggedInUserId;

    /**
     * @var CalendarEventCategoryRepository
     */
    private $calendarEventCategoryRepository;

    /**
     * @var AppointmentService
     */
    private $apptService;

    public function __construct(SystemLogger $logger, $assetPath, $loggedInUserId)
    {
        $this->logger = $logger;
        $this->assetPath = $assetPath;
        $this->loggedInUserId = $loggedInUserId;
        $this->calendarEventCategoryRepository = new CalendarEventCategoryRepository();
        $this->apptService = new AppointmentService();
    }

    public function subscribeToEvents(EventDispatcher $eventDispatcher)
    {
        $eventDispatcher->addListener(CalendarUserGetEventsFilter::EVENT_NAME, [$this, 'filterTelehealthCalendarEvents']);
        $eventDispatcher->addListener(ScriptFilterEvent::EVENT_NAME, [$this, 'addCalendarJavascript']);
        $eventDispatcher->addListener(StyleFilterEvent::EVENT_NAME, [$this, 'addCalendarStylesheet']);
        $eventDispatcher->addListener(AppointmentRenderEvent::RENDER_BELOW_PATIENT, [$this, 'renderAppointmentsLaunchSessionButton']);
    }

    public function filterTelehealthCalendarEvents(CalendarUserGetEventsFilter $event)
    {

        $eventsByDay = $event->getEventsByDays();
        $keys = array_keys($eventsByDay);
        $apptService = $this->apptService;
        foreach ($keys as $key) {
            $eventCount = count($eventsByDay[$key]);
            for ($i = 0; $i < $eventCount; $i++) {
                $catId = $eventsByDay[$key][$i]['catid'];
                // we need to also check and see if the event is an old event (ie less than today's date)
                if (!empty($this->calendarEventCategoryRepository->getEventCategoryForId($catId))) {
                    $eventViewClasses = ["event_appointment", "event_telehealth"];
                    $dateTime = \DateTime::createFromFormat("Y-m-d H:i:s", $eventsByDay[$key][$i]['eventDate']
                        . " " . $eventsByDay[$key][$i]['startTime']);

                    // if the event belongs to a different user then we need to go get it.
                    if ($eventsByDay[$key][$i]['aid'] != $this->loggedInUserId) {
                        $this->logger->debug(
                            "TeleHealthCalendarController->filterTelehealthCalendarEvents() different user id then logged in user",
                            ['assignedProvider' => $eventsByDay[$key][$i]['aid'], 'loggedinProvider' => $this->loggedInUserId]
                        );
                        $eventViewClasses[] = "event_user_different";
                    }

                    if ($apptService->isCheckOutStatus($eventsByDay[$key][$i]['apptstatus'])) {
                        $eventViewClasses[] = "event_telehealth_completed";
                    } else if ($dateTime !== false && CalendarUtils::isAppointmentDateTimeInSafeRange($dateTime)) {
                        $this->logger->debug("calendarEvent filter  Time is ", ['time' => $dateTime]);
                        $eventViewClasses[] = "event_telehealth_active";
                    } else if ($dateTime == false) {
                        $this->logger->errorLogCaller("Failed to create DateTime object for calendar event", ['pc_eid' => $eventsByDay[$key][$i]['eid']]);
                    }
                    $eventsByDay[$key][$i]['eventViewClass'] = implode(" ", $eventViewClasses);
                }
            }
        }
        $event->setEventsByDays($eventsByDay);
        return $event;
    }

    public function addCalendarStylesheet(StyleFilterEvent $event)
    {
        if ($this->isCalendarPageInclude($event->getPageName())) {
            $styles = $event->getStyles();
            $styles[] = $this->getAssetPath() . "css/telehealth.css";
            $event->setStyles($styles);
        }
    }

    public function addCalendarJavascript(ScriptFilterEvent $event)
    {
        if ($this->isCalendarPageInclude($event->getPageName())) {
            $scripts = $event->getScripts();
            // currently security restrictions support scripts only on the filesystem.  Translations then
            // are being pulled from the top level comlink instead of the inner iframe.  We may need to adjust this
            // if we run into issues.
//            $scripts[] = $this->getAssetPath() . "../index.php?action=get_translations";
            $scripts[] = $this->getAssetPath() . "js/telehealth-calendar.js";
            $event->setScripts($scripts);
        }
    }


    public function renderAppointmentsLaunchSessionButton(AppointmentRenderEvent $event)
    {
        $row = $event->getAppt();
        if (empty($row['pc_eid'])) {
            return;
        }
        if (empty($this->calendarEventCategoryRepository->getEventCategoryForId($row['pc_catid']))) {
            return;
        }
        // don't show the launch button for a complete status
        if ($this->apptService->isCheckOutStatus($row['pc_apptstatus'])) {
            return;
        }
        echo "<script src='" . $this->getAssetPath() . "js/telehealth-calendar.js" . "'></script>";
        echo "<button data-eid='" . attr($row['pc_eid']) . "' data-pid='" . attr($row['pc_pid'])
            . "' class='mt-2 btn btn-primary btn-add-edit-appointment-launch-telehealth'><i class='fa fa-video m-2'></i>"
            . xlt("Launch TeleHealth Session") . "</button>";
    }


    private function isCalendarPageInclude($pageName)
    {
        return $pageName == 'pnuserapi.php' || $pageName == 'pnadmin.php';
    }

    private function getAssetPath()
    {
        return $this->assetPath;
    }
}
