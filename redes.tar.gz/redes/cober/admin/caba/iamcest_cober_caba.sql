-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 17-12-2020 a las 14:49:32
-- Versión del servidor: 10.3.17-MariaDB
-- Versión de PHP: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `iamcest_publico_caba`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(4) NOT NULL,
  `adminName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `adminUsrName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `adminDob` varchar(10) CHARACTER SET latin1 NOT NULL,
  `adminPass` varchar(30) CHARACTER SET latin1 NOT NULL,
  `adminPhone` bigint(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`admin_id`, `adminName`, `adminUsrName`, `adminDob`, `adminPass`, `adminPhone`) VALUES
(1, 'Admin1', 'Admin1', '06/08/1996', 'admin1', 1150500147),
(2, 'Admin2', 'Admin2', '07/08/2000', 'admin2', 1150500147);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `appoinment`
--

CREATE TABLE `appoinment` (
  `id` int(4) NOT NULL,
  `appoinment_id` varchar(10) CHARACTER SET latin1 NOT NULL,
  `patient_id` int(4) NOT NULL,
  `doctor_id` int(4) NOT NULL,
  `doctor_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `department` varchar(30) CHARACTER SET latin1 NOT NULL,
  `patient_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `appointment_date` varchar(10) CHARACTER SET latin1 NOT NULL,
  `appoinment_time` varchar(10) CHARACTER SET latin1 NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 NOT NULL,
  `status` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `appoinment`
--

--
-- Estructura de tabla para la tabla `department`
--

CREATE TABLE `department` (
  `department_id` int(3) NOT NULL,
  `department_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `department_status` varchar(25) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `department_status`) VALUES
(1, 'SANATORIO COLEGIALES', 'Activo'),

CREATE TABLE `doctor` (
  `doctor_id` int(4) NOT NULL,
  `doctor_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `department` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `userName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `pass` varchar(30) CHARACTER SET latin1 NOT NULL,
  `dateOfBirth` varchar(30) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(10) CHARACTER SET latin1 NOT NULL,
  `addrss` varchar(100) CHARACTER SET latin1 NOT NULL,
  `city` varchar(30) CHARACTER SET latin1 NOT NULL,
  `Province` varchar(30) CHARACTER SET latin1 NOT NULL,
  `postalCode` int(6) NOT NULL,
  `phone` bigint(10) DEFAULT NULL,
  `profilePic` longblob NOT NULL,
  `shortBio` varchar(100) CHARACTER SET latin1 NOT NULL,
  `docStatus` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `doctor`
--


CREATE TABLE `doctor_schedule` (
  `schedule_id` int(5) NOT NULL,
  `department_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `doctorName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `availDays` varchar(30) CHARACTER SET latin1 NOT NULL,
  `startTime` varchar(10) CHARACTER SET latin1 NOT NULL,
  `endTime` varchar(10) CHARACTER SET latin1 NOT NULL,
  `status` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `doctor_schedule`
--

CREATE TABLE `employee` (
  `emp_id` int(5) NOT NULL,
  `empName` varchar(20) CHARACTER SET latin1 NOT NULL,
  `age` int(3) NOT NULL,
  `userName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` varchar(30) CHARACTER SET latin1 NOT NULL,
  `joinDate` varchar(30) CHARACTER SET latin1 NOT NULL,
  `phone` bigint(10) NOT NULL,
  `role` varchar(30) CHARACTER SET latin1 NOT NULL,
  `empStatus` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `employee`
--
-- Estructura Stand-in para la vista `employeelist`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `employeelist` (
`emp_id` int(5)
,`empName` varchar(20)
,`email` varchar(100)
,`phone` bigint(10)
,`joinDate` varchar(30)
,`role` varchar(30)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicine`
--

CREATE TABLE `medicine` (
  `medicine_id` int(4) NOT NULL,
  `medicine_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `medicine_exp` date NOT NULL,
  `medicine_stock` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(4) NOT NULL,
  `patientdni` varchar(8) CHARACTER SET utf8mb4 NOT NULL,
  `patient_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `consultingDoctor` varchar(100) CHARACTER SET latin1 NOT NULL,
  `username` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `pssword` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `dateOfBirth` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `addrss` varchar(200) CHARACTER SET latin1 NOT NULL,
  `city` varchar(30) CHARACTER SET latin1 NOT NULL,
  `province` varchar(30) CHARACTER SET latin1 NOT NULL,
  `postalCode` int(7) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `UserPic` longblob NOT NULL,
  `patientStatus` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `patient`
--
--
-- Estructura Stand-in para la vista `patientlist`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `patientlist` (
`patient_name` varchar(30)
,`dateOfBirth` varchar(20)
,`addrss` varchar(200)
,`phone` bigint(10)
,`email` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pharmacy`
--

CREATE TABLE `pharmacy` (
  `order_id` int(4) NOT NULL,
  `doctor_id` int(4) NOT NULL,
  `patient_id` int(4) NOT NULL,
  `medicine_id` int(4) NOT NULL,
  `medicine_name` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prescription`
--

CREATE TABLE `prescription` (
  `prescription_id` int(4) NOT NULL,
  `doctor_id` int(4) NOT NULL,
  `patient_id` int(4) NOT NULL,
  `medicine_name` varchar(250) CHARACTER SET latin1 NOT NULL,
  `currentDate` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test`
--

CREATE TABLE `test` (
  `test_id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `patient_id` int(10) NOT NULL,
  `test` varchar(250) CHARACTER SET latin1 NOT NULL,
  `currentDate` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `test`
--

INSERT INTO `test` (`test_id`, `doctor_id`, `patient_id`, `test`, `currentDate`) VALUES
(10, 41, 35, 'Test20,Test25', '2019-11-14'),
(8, 41, 34, 'Test one,Testtwo', '2019-11-14');

-- --------------------------------------------------------

--
-- Estructura para la vista `employeelist`
--
DROP TABLE IF EXISTS `employeelist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employeelist`  AS  select `employee`.`emp_id` AS `emp_id`,`employee`.`empName` AS `empName`,`employee`.`email` AS `email`,`employee`.`phone` AS `phone`,`employee`.`joinDate` AS `joinDate`,`employee`.`role` AS `role` from `employee` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `patientlist`
--
DROP TABLE IF EXISTS `patientlist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patientlist`  AS  select `patient`.`patient_name` AS `patient_name`,`patient`.`dateOfBirth` AS `dateOfBirth`,`patient`.`addrss` AS `addrss`,`patient`.`phone` AS `phone`,`patient`.`email` AS `email` from `patient` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indices de la tabla `appoinment`
--
ALTER TABLE `appoinment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `department` (`department`);

--
-- Indices de la tabla `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indices de la tabla `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`),
  ADD KEY `department` (`department`);

--
-- Indices de la tabla `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indices de la tabla `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indices de la tabla `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indices de la tabla `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indices de la tabla `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `medicine_id` (`medicine_id`);

--
-- Indices de la tabla `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`prescription_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indices de la tabla `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `appoinment`
--
ALTER TABLE `appoinment`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  MODIFY `schedule_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `prescription`
--
ALTER TABLE `prescription`
  MODIFY `prescription_id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `test`
--
ALTER TABLE `test`
  MODIFY `test_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
