<?php
include('connection.php');
session_start();
$doc="select * from doctor";
$result=$conn->query($doc);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>RED IAMCEST | PUBLICO | CABA | PROFESIONALES</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
    <div class="main-wrapper">
        <div class="header">
			<div class="header-left">
				<a href="index.php" class="logo">
					<img src="assets/img/logo-iamcest.png" width="35" height="35" alt=""> <span>GCABA | SAME</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
            <ul class="nav user-menu float-right">
                <li class="nav-item dropdown has-arrow">
                    <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img"><img class="rounded-circle" src="assets/img/user.jpg" width="40" alt="Admin">
							<span class="status online"></span></span>
                        <span><?php echo $_SESSION['username']?></span>
                    </a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="userprofile.php">Mi Perfil</a>
						<a class="dropdown-item" href="logout.php">Salir</a>
					</div>
                </li>
            </ul>
            <div class="dropdown mobile-user-menu float-right">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="adminprofile.php">My Profile</a>
                    <!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>
                    <a class="dropdown-item" href="settings.html">Settings</a>-->
                    <a class="dropdown-item" href="adminLogout.php">Logout</a>
                </div>
            </div>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: 100%; height: 597px;"><div class="sidebar-inner slimscroll" style="overflow: hidden; width: 100%; height: 597px;">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Principal</li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                        <li>
                            <a href="hospitales.php"><i class="fa fa-hospital-o"></i> <span>Hospitales</span></a>
                        </li>
			<li class="active">
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li>
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <!--<li>
                            <a href="colaboradores.php"><i class="fa fa-user-circle"></i> <span>Colaboradores</span></a>
                        </li>-->
                        <li>
                    	    <a href="turnos.php"><i class="fa fa-calendar-check-o"></i> <span>Turnos</span></a>
                    	</li>
                        <!--<li>
                            <a href="agenda.php"><i class="fa fa-calendar"></i> <span>Agenda</span></a>
                        </li>
                        <li>
                            <a href="https://diag.iamcest.com"><i class="fa fa-comments"></i> <span>Chat </span></a>
                        </li>-->
                    </ul>
                </div>
            </div><div class="slimScrollBar" style="background: rgb(204, 204, 204); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 296.658px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
        </div>
        <div class="page-wrapper" style="min-height: 657px;">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Profesionales</h4>
                    </div>
                    <!--<div class="col-sm-8 col-9 text-right m-b-20">
                        <a href="agregar-profesionales.php" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Agregar Profesionles</a>
                    </div>-->
                </div>
                <div class="row doctor-grid">
                <?php
                                                        while($doctor=$result->fetch_assoc())
                                                        {
                                                            $docpropic=$doctor['profilePic'];
                                                            $dept=$doctor['department'];
                                                            $docname=$doctor['doctor_name'];
                                                            $city=$doctor['city'];
                ?>
                    
                    <div class="col-md-4 col-sm-4  col-lg-3">
                        <div class="profile-widget">
                            <div class="doctor-img">
                                <a class="avatar" href="#"><img alt="" src="Images/<?php echo $docpropic?>"></a>
                            </div>
                            <div class="dropdown profile-action">
                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="edit-doctor.html"><i class="fa fa-pencil m-r-5"></i> Editar</a>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_doctor"><i class="fa fa-trash-o m-r-5"></i> Borrar</a>
                                </div>
                            </div>
                            <h4 class="doctor-name text-ellipsis"><a href="docprofile.php"><?php echo $docname ?></a></h4>
                            <div class="doc-prof"><?php echo $dept ?></div>
                            <div class="user-country">
                                <i class="fa fa-map-marker"></i> <?php echo $city ?>
                            </div>
                        </div>
                    </div>
                                                        <?php } ?>
                </div>
				<!-- <div class="row">
                    <div class="col-sm-12">
                        <div class="see-all">
                            <a class="see-all-btn" href="javascript:void(0);">Load More</a>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
		<div id="delete_doctor" class="modal fade delete-modal" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-body text-center">
						<img src="assets/img/sent.png" alt="" width="50" height="46">
						<h3>Are you sure want to delete this Doctor?</h3>
						<div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
							<button type="submit" class="btn btn-danger">Delete</button>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
