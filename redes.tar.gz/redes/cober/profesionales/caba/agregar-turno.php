<?php 
include('connection.php');
session_start();
$tempId=$_SESSION['id'];
					$sql = "SELECT * FROM `patient` WHERE patient_id = '$tempId'";  
 					$result = mysqli_query($conn, $sql); 
					$row = mysqli_fetch_array($result);
if (isset($_POST['submit'])) {
$str=$_POST['docName'];
$demo = explode(",",$str);
$doctorId= $demo[1];
							//find max
							$qurry_auto_id = "SELECT COUNT(doctor_id)FROM `appoinment`  where doctor_id = '$doctorId'  and status = 'active'";
							$result_auto_id = mysqli_query($conn, $qurry_auto_id);
							$row_auto_id = mysqli_fetch_array($result_auto_id);
							$Current_id =  $row_auto_id['COUNT(doctor_id)']+1;
							$newID= "APT-" .date("md"). $Current_id; echo $newID;
    $appId = $newID;
    $patientId=$_POST['patientId'];
    $doctorName = $demo[0];
    $department=$_POST['dpt'];
    $patientName=$_SESSION['username'];
    $patientMail=$_POST['email'];
    $patientPhone=$_POST['phone'];
    $patientStatus=$_POST['status'];
    $appoinDate=$_POST['appDate'];
    $appoinTime=$_POST['appTime'];
    $SuccMessage="Turno cargado correctamente!! Turno ID : ".$appId;
    $failMessage="Horario no disponible. Seleccione otro!";

$sql = "INSERT INTO `appoinment`(`appoinment_id`, `patient_id`, `doctor_id`, `doctor_name`, `department`, `patient_name`, `appointment_date`, `appoinment_time`,`phone`, `email`, `status`) VALUES ('$appId','$patientId','$doctorId','$doctorName','$department','$patientName','$appoinDate','$appoinTime','$patientPhone','$patientMail','$patientStatus')";
							$qurry_time= "SELECT COUNT(doctor_id)FROM `appoinment`  where doctor_id = '$doctorId'  and appoinment_time = '$appoinTime' and status = 'active'";
							$result_time = mysqli_query($conn, $qurry_time);
							$row_time = mysqli_fetch_array($result_time);
							$Current_time =  $row_time['COUNT(doctor_id)'];
  if($Current_time >= 1) {  echo  "<script type='text/javascript'>alert('$failMessage');</script>";
  } else {
if ($conn->query($sql)) {
    echo  "<script type='text/javascript'>alert('$SuccMessage');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>IAMCEST | RED CABA | AGREGAR TURNOS</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
	
</head>
<body>
    <div class="main-wrapper">
        <div class="header">
			<div class="header-left">
				<a href="index.php" class="logo">
					<img src="assets/img/logo-iamcest.png" width="35" height="35" alt=""> <span> COBER</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
            <ul class="nav user-menu float-right">
                <li class="nav-item dropdown has-arrow">
                    <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img"><img class="rounded-circle" src="Images/<?php echo $row['UserPic']?>" width="40" alt="Admin">
			<span class="status online"></span></span>
                        <span><?php echo $_SESSION['username']?></span>
                    </a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="docprofile.php">Mi Perfil</a>
				<!--<a class="dropdown-item" href="edit-profile.html">Editar Perfil</a>
				<a class="dropdown-item" href="settings.html">Seteos</a>-->
				<a class="dropdown-item" href="logout.php">Salir</a>
			</div>
                </li>
            </ul>
            <div class="dropdown mobile-user-menu float-right">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="docprofile.php">My Profile</a>
                    <!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>
                    <a class="dropdown-item" href="settings.html">Settings</a>-->
                    <a class="dropdown-item" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Principal</li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                        <li>
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li>
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <li class="active">
                            <a href="turnos.php"><i class="fa fa-calendar-check-o"></i> <span>Turnos</span></a>
                        </li>
                        <li>
                            <a href="agenda.php"><i class="fa fa-calendar"></i> <span>Agenda</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Agregar Turno</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form method="post">
                            <div class="row">
                                
                                <div class="col-md-12">
									<div class="form-group">
										<label>ID Paciente</label>
										<input class="form-control"  name="patientId" type="text" value="<?php echo $_SESSION['id']; ?> "readonly="">
									</div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Sanatorio</label>
                                        <select class="select" name="dpt" onChange="sel_doc(this)">
                                            <!--<option>Select</option>
                                            <option>Dentists</option>
                                            <option>Neurology</option>
                                            <option>Opthalmology</option>
                                            <option>Orthopedics</option>
                                            <option>Cancer Department</option>
                                            <option>ENT Department</option>-->
											<?php  
									  $sql = "SELECT  department_name FROM department;";  
 									$result = mysqli_query($conn, $sql); 
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          
                               <option value="<?php echo $row["department_name"];?>" ><?php echo $row["department_name"];?></option>"
                               
                           
                          <?php  
                          }  
                          ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Profesionales</label>
                                        <select class="select" name="docName">
											<!--<option>Select</option>
											<option>Cristina Groves</option>
											<option>Marie Wells</option>
											<option>Henry Daniels</option>-->
											<?php  
include('connection.php');
										//$sql="SELECT doctor.doctor_name,doctor.doctor_id FROM doctor INNER JOIN department ON department.department_name = doctor.department WHERE department = '$department'";
//doctor.'$department'
									  $sql = "SELECT doctor_name, doctor_id FROM doctor ;";  
 									$result = mysqli_query($conn, $sql); 
									echo "error:" . $sql. "<br>".mysqli_error($conn);
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          
                               <option value="<?php echo $row['doctor_name'].",". $row['doctor_id'];?>"><?php echo $row['doctor_name'];?></option>"
							  
                               <?php echo "error:" . $sql. "<br>".mysqli_error($conn);?>
                           
                          <?php  
                          } 
                          ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Fecha</label>
                                        <div class="cal-icon">
                                            <input type="text"  name="appDate" class="form-control datetimepicker">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Horario</label>
                                        <div class="time-icon">
                                            <input type="text"  name="appTime" class="form-control" id="datetimepicker3">
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
					$tempId=$_SESSION['id'];
					$sql = "SELECT * FROM `patient` WHERE patient_id = '$tempId'";  
 					$result = mysqli_query($conn, $sql); 
					$row = mysqli_fetch_array($result);
				?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email Paciente</label>
                                        <input class="form-control"  name="email" type="email" value="<?php echo $row['email'];?>" readonly="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Celular Paciente (10 dígitos)</label>
                                        <input class="form-control"   name="phone" value="<?php echo $row['phone'];?>"type="text" readonly="">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Mensaje (Breve)</label>
                                <textarea cols="30" rows="4" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label class="display-block">Estado del Turno</label>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_active" value="Active" checked>
									<label class="form-check-label" for="product_active">
									Activo
									</label>
								</div>
								<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="status" id="product_inactive" value="Inactive">
									<label class="form-check-label" for="product_inactive">
									Inactivo
									</label>
								</div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn" name="submit" type="submit">Agregar Turno</button>
                            </div>
                        </form>
						
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
	<script>
            $(function () {
                $('#datetimepicker3').datetimepicker({
                    format: 'LT'

                });
            });
     </script>
	 <script>
	  function sel_doc(id)
  {
  console.log(id);
      jQuery.ajax({
       type: "POST",
       url: "sel_doc.php",
       data: department.value,
       cache: false,
       success: function(response)
       {
         console.log (data);
        }
     });
 }
	 </script>
	
</body>
</html>
