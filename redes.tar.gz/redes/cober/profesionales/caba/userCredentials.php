<?php
include('connection.php');
session_start();
			
					$tempId=$_SESSION['id'];
					$appid= $_GET['appid'];
					$sql = "SELECT * FROM `appoinment` WHERE appoinment_id = '$appid' and status ='Active' and doctor_id='$tempId' ";  
 					$result = mysqli_query($conn, $sql); 
					$row = mysqli_fetch_array($result);
					//$apid= $row['appoinment_id'];
					$pid= $row['patient_id'];
					
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>IAMCEST | RED INFARTO | PACIENTE</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <div class="header">
			<div class="header-left">
				<a href="index.php" class="logo">
					<img src="assets/img/logo-iamcest.png" width="35" height="35" alt=""> <span> COBER</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
            <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
            <ul class="nav user-menu float-right">
                <li class="nav-item dropdown d-none d-sm-block">
                    <a href="javascript:void(0);" id="open_msg_box" class="hasnotifications nav-link"><i class="fa fa-comment-o"></i> <span class="badge badge-pill bg-danger float-right">8</span></a>
                </li>
                <li class="nav-item dropdown has-arrow">
                    <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img"><img class="rounded-circle" src="assets/img/user.png" width="40" alt="Dr">
			<span class="status online"></span></span>
                        <span><?php echo $_SESSION['username']?> </span>
                    </a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="docprofile.php">Mi Perfil</a>
						<a class="dropdown-item" href="logout.php">Salir</a>
					</div>
                </li>
            </ul>
            <div class="dropdown mobile-user-menu float-right">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="docprofile.php">Mi Perfil</a>
                    <a class="dropdown-item" href="logout.php">Salir</a>
                </div>
            </div>
        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li>
                            <a href="profesionales.php"><i class="fa fa-user-md"></i> <span>Profesionales</span></a>
                        </li>
                        <li>
                            <a href="pacientes.php"><i class="fa fa-user-o"></i> <span>Pacientes</span></a>
                        </li>
                        <li>
                            <a href="turnos.php"><i class="fa fa-calendar"></i> <span>Turnos</span></a>
                        </li>
                        <li>
                            <a href="agendas.html"><i class="fa fa-calendar-check-o"></i> <span>Agendas</span></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-7 col-6">
                        <h4 class="page-title">Datos del Paciente</h4>
                    </div>

                    <div class="col-sm-5 col-6 text-right m-b-30">
<!--                        <a href="edit-profile.html" class="btn btn-primary btn-rounded"><i class="fa fa-plus"></i> Edit Profile</a>
-->                    </div>
                </div>
			
                <div class="card-box profile-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#"><img class="avatar" src="assets/img/doctor-03.jpg" alt=""></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo $row['patient_name']; ?></h3>
                                                <small class="text-muted">Rol : Paciente</small>
                                                <div class="staff-id">ID Paciente : <?php echo $row['patient_id']; ?></div>
                                                <div class="staff-msg"><a href="update.php?appid=<?=$appid?>&pid=<?=$pid?>" class="btn btn-primary">Cargar Evolución</a></div>
                                            </div>
                                        </div>
                                        <div class="col-md-7" style="height:150px;">
                                            <ul class="personal-info">
                                                <li>
                                                    <span class="title">Teléfono:</span>
                                                    <span class="text"><a href="#"><?php echo $row['phone']; ?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Email:</span>
                                                    <span class="text"><a href="#"><?php echo $row['email']; ?></a></span>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
				<div class="profile-tabs">
					<ul class="nav nav-tabs nav-tabs-bottom">
						<li class="nav-item"><a class="nav-link active" href="#about-cont" data-toggle="tab">Acerca</a></li>
						<li class="nav-item"><a class="nav-link" href="#bottom-tab2" data-toggle="tab">Prescripción</a></li>
						<li class="nav-item"><a class="nav-link" href="#bottom-tab3" data-toggle="tab">Estudios</a></li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane show active" id="about-cont"><br>

							<div class="row">
               				<div class="col-lg-6">
                        <div class="card-box">
						<h4 class="card-title">Indicaciones Tratamiento</h4>
                            <div class="card-block">
                               <div class="table-responsive">
							  
									<table class="table mb-0">
										<thead>
											<tr>
												<th>ID</th>
												<th>Fecha</th>
												<th>Nombre genérico</th>
												
											</tr>
										</thead>
										<tbody>
										 <?php
					$tempId=$_SESSION['id'];
					$patientId=$row['patient_id'];
					$sql_pre= "SELECT * FROM `prescription` WHERE doctor_id = '$tempId' and patient_id ='$patientId'";  
 					$result_pre= mysqli_query($conn, $sql_pre); 
					if(mysqli_num_rows($result_pre)>0){
						while($row_pre = mysqli_fetch_array($result_pre)){
						//$flag = $row['appoinment_id'];
						$str=$row_pre['medicine_name'];
						$demo = explode(",",$str);$count = count($demo);
						
					//	$doctorId= $demo[0];

					
				?>
											<tr>
												<td><?php echo $row_pre['prescription_id']; ?></td>
												<td><?php echo $row_pre['currentDate']; ?></td>
												<td><?php for($i=0;$i<$count;$i++){ echo $demo[$i]; ?> </br><?php } ?></td>
											</tr>
											<?php } }?>
										</tbody>
									</table>
								</div>
                            </div>
                        </div>
						</div>
						
						
						<div class="col-lg-6">
                        <div class="card-box">
						<h4 class="card-title">Estudios Solicitados</h4>
                            <div class="card-block">
                               <div class="table-responsive">
							  
									<table class="table mb-0">
										<thead>
											<tr>
												<th>ID</th>
												<th>Fecha</th>
												<th>Nombre Estudio</th>
												
											</tr>
										</thead>
										<tbody>
										 <?php
					$tempId=$_SESSION['id'];
					$patientId=$row['patient_id'];
					$sql_test= "SELECT * FROM `test` WHERE doctor_id = '$tempId' and patient_id ='$patientId'";  
 					$result_test= mysqli_query($conn, $sql_test); 
					if(mysqli_num_rows($result_test)>0){
						while($row_test = mysqli_fetch_array($result_test)){
						//$flag = $row['appoinment_id'];
						$str=$row_test['test'];
						$demo = explode(",",$str);$count = count($demo);
						
					//	$doctorId= $demo[0];

					
				?>
											<tr>
												<td><?php echo $row_test['test_id']; ?></td>
												<td><?php echo $row_test['currentDate']; ?></td>
												<td><?php for($i=0;$i<$count;$i++){ echo $demo[$i]; ?> </br><?php } ?></td>
											</tr>
											<?php } }?>
										</tbody>
									</table>
								</div>
                            </div>
                        </div>
						</div>
						
						
                    </div>
					
						</div>
						
						<div class="tab-pane" id="bottom-tab2">
						<form method="post">
							<textarea class="form-control" rows="3" cols="1000" name="precription" required></textarea>
							<br>
							<br>
							 <button class="btn btn-primary submit-btn" name="submit">Enviar</button>
							 </form>
							 
							<?php if (isset($_POST['submit'])) {
    $docId=$_SESSION['id'];
    $patientId=$row['patient_id'];
    $medicineName=$_POST['precription'];
	$date=date("Y-m-d");
    $SuccMessage="Indicación cargada correctamente!!";

$sql = "INSERT INTO `prescription`(`doctor_id`, `patient_id`, `medicine_name`, `currentDate`) VALUES ('$docId','$patientId','$medicineName','$date')";

if ($conn->query($sql)) {
    echo  "<script type='text/javascript'>alert('$SuccMessage');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}
?>

						</div>
						<div class="tab-pane" id="bottom-tab3">
						<form method="post">
							<textarea class="form-control" rows="3" cols="1000" name="test" required></textarea>
							<br><br>
							<button class="btn btn-primary submit-btn" name="submitTest">Enviar</button>
							</form>
							<?php if (isset($_POST['submitTest'])) {
    $docId=$_SESSION['id'];
    $patientId=$row['patient_id'];
    $test=$_POST['test'];
	$date=date("Y-m-d");
    $SuccMessage="Estudio solicitado correctamente!!";

$sql = "INSERT INTO `test`(`doctor_id`, `patient_id`, `test`, `currentDate`) VALUES ('$docId','$patientId','$test','$date')";

if ($conn->query($sql)) {
    echo  "<script type='text/javascript'>alert('$SuccMessage');</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>
						</div>
					</div>
				</div>
            </div>
            <div class="notification-box">
                <div class="msg-sidebar notifications msg-noti">
                    <div class="topnav-dropdown-header">
                        <span>Messages</span>
                    </div>
                    <div class="drop-scroll msg-list-scroll" id="msg_list">
                        <ul class="list-box">
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">R</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Richard Miles </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item new-message">
                                        <div class="list-left">
                                            <span class="avatar">J</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">John Doe</span>
                                            <span class="message-time">1 Aug</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">T</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Tarah Shropshire </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">M</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Mike Litorus</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">C</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Catherine Manseau </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">D</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Domenic Houston </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">B</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Buster Wigton </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">R</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Rolland Webber </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">C</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Claire Mapes </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">M</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Melita Faucher</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">J</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Jeffery Lalor</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">L</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Loren Gatlin</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">T</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Tarah Shropshire</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="topnav-dropdown-footer">
                        <a href="chat.html">See all messages</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>