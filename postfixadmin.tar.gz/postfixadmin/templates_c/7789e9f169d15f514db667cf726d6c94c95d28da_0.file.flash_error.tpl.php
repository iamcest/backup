<?php
/* Smarty version 3.1.33, created on 2022-01-25 19:39:49
  from '/usr/share/nginx/postfixadmin/templates/flash_error.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f052052ca797_39605333',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7789e9f169d15f514db667cf726d6c94c95d28da' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/flash_error.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61f052052ca797_39605333 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- <?php echo basename($_smarty_tpl->source->filepath);?>
 -->
<br clear="all"/><br/>
<?php if (isset($_SESSION['flash'])) {
if (isset($_SESSION['flash']['info'])) {?><div class="alert alert-info" role="alert"><ul class="flash-info"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_SESSION['flash']['info'], 'msg');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
?><li><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['msg']->value, ENT_QUOTES, 'UTF-8', true);?>
</li><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?></ul></div><?php }
if (isset($_SESSION['flash']['error'])) {?><div class="alert alert-danger" role="alert"><ul class="flash-error"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_SESSION['flash']['error'], 'msg');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
?><li><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['msg']->value, ENT_QUOTES, 'UTF-8', true);?>
</li><?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?></ul></div><?php }
}
}
}
