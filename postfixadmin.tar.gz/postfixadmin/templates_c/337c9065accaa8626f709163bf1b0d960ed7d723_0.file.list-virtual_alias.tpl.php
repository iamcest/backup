<?php
/* Smarty version 3.1.33, created on 2022-01-25 20:02:07
  from '/usr/share/nginx/postfixadmin/templates/list-virtual_alias.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f0573f945055_63591941',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '337c9065accaa8626f709163bf1b0d960ed7d723' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/list-virtual_alias.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:list.tpl' => 1,
  ),
),false)) {
function content_61f0573f945055_63591941 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_assignInScope('table', 'alias');
$_smarty_tpl->_assignInScope('struct', $_smarty_tpl->tpl_vars['alias_data']->value['struct']);
$_smarty_tpl->_assignInScope('msg', $_smarty_tpl->tpl_vars['alias_data']->value['msg']);
$_smarty_tpl->_assignInScope('id_field', $_smarty_tpl->tpl_vars['msg']->value['id_field']);
$_smarty_tpl->_assignInScope('formconf', $_smarty_tpl->tpl_vars['alias_data']->value['formconf']);
$_smarty_tpl->_assignInScope('items', $_smarty_tpl->tpl_vars['tAlias']->value);
$_smarty_tpl->_assignInScope('RAW_items', $_smarty_tpl->tpl_vars['RAW_tAlias']->value);?>

<?php $_smarty_tpl->_subTemplateRender('file:list.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
