<?php
/* Smarty version 3.1.33, created on 2022-01-26 00:34:59
  from '/usr/share/nginx/postfixadmin/templates/broadcast-message.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f097336abd68_77070207',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2d4a6125796eaac5657f58c8cf42e46835a1905' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/broadcast-message.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61f097336abd68_77070207 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/usr/share/nginx/postfixadmin/lib/smarty/libs/plugins/function.html_options.php','function'=>'smarty_function_html_options',),));
?>
<form name="broadcast-message" method="post" action="" class="form-horizontal">
<div id="edit_form" class="panel panel-default">
	<div class="panel-heading"><h4><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pBroadcast_title'];?>
</h4></div>
	<div class="panel-body">
		<input class="flat" type="hidden" name="token" value="<?php echo rawurlencode($_SESSION['PFA_token']);?>
" />
		<div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['from'];?>
:</label>
                        <div class="col-md-6 col-sm-8"><p class="form-control-static"><em><?php echo $_smarty_tpl->tpl_vars['smtp_from_email']->value;?>
</em></p></div>
                </div>
		<div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label" for="name"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pBroadcast_name'];?>
:</label>
                        <div class="col-md-6 col-sm-8"><input class="form-control" type="text" name="name" id="name" /></div>
                </div>
		<div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label" for="subject"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['subject'];?>
:</label>
                        <div class="col-md-6 col-sm-8"><input class="form-control" type="text" name="subject" id="subject" /></div>
                </div>
                <div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label" for="message"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['message'];?>
:</label>
                        <div class="col-md-6 col-sm-8"><textarea class="form-control" rows="6" cols="40" name="message" id="message"></textarea></div>
                </div>
		<div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label"></label>
                        <div class="col-md-6 col-sm-8"><div class="checkbox"><label><input type="checkbox" value="1" name="mailboxes_only"/><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['broadcast_mailboxes_only'];?>
</label></div></div>
                </div>
		<div class="form-group">
                        <label class="col-md-4 col-sm-4 control-label" for="domains"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['broadcast_to_domains'];?>
</label>
                        <div class="col-md-6 col-sm-8">
				<select multiple="multiple" name="domains[]" id="domains" class="form-control">
					<?php echo smarty_function_html_options(array('output'=>$_smarty_tpl->tpl_vars['allowed_domains']->value,'values'=>$_smarty_tpl->tpl_vars['allowed_domains']->value,'selected'=>$_smarty_tpl->tpl_vars['allowed_domains']->value),$_smarty_tpl);?>

				</select>
			</div>
                </div>
	</div>
        <div class="panel-footer">
                <div class="btn-toolbar" role="toolbar">
                        <div class="btn-group pull-right">
                        <input class="btn btn-primary" type="submit" name="submit" value="<?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pSendmail_button'];?>
" />
                        </div>
                </div>
        </div>
</div>
</form>
<?php }
}
