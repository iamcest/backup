<?php
/* Smarty version 3.1.33, created on 2022-01-25 20:02:07
  from '/usr/share/nginx/postfixadmin/templates/list-virtual_alias_domain.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f0573f93e461_75213729',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a9824bf0f432d26aa873f56b0c557d10e33ce8c8' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/list-virtual_alias_domain.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:list.tpl' => 1,
  ),
),false)) {
function content_61f0573f93e461_75213729 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_assignInScope('table', 'aliasdomain');
$_smarty_tpl->_assignInScope('struct', $_smarty_tpl->tpl_vars['aliasdomain_data']->value['struct']);
$_smarty_tpl->_assignInScope('msg', $_smarty_tpl->tpl_vars['aliasdomain_data']->value['msg']);
$_smarty_tpl->_assignInScope('id_field', $_smarty_tpl->tpl_vars['msg']->value['id_field']);
$_smarty_tpl->_assignInScope('formconf', $_smarty_tpl->tpl_vars['aliasdomain_data']->value['formconf']);
$_smarty_tpl->_assignInScope('items', $_smarty_tpl->tpl_vars['tAliasDomains']->value);
$_smarty_tpl->_assignInScope('RAW_items', $_smarty_tpl->tpl_vars['RAW_tAliasDomains']->value);?>

<?php $_smarty_tpl->_subTemplateRender('file:list.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
