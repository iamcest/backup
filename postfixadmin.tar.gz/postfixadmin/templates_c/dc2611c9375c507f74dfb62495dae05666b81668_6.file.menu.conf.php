<?php /* Smarty version 3.1.33, created on 2022-01-25 19:59:42
         compiled from '/usr/share/nginx/postfixadmin/configs/menu.conf' */ ?>
<?php
/* Smarty version 3.1.33, created on 2022-01-25 19:59:42
  from '/usr/share/nginx/postfixadmin/configs/menu.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f056ae86be46_21878054',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dc2611c9375c507f74dfb62495dae05666b81668' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/configs/menu.conf',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61f056ae86be46_21878054 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'adminlistadmin' => 
    array (
      'vars' => 
      array (
        'url_edit_admin' => 'edit.php?table=admin',
      ),
    ),
  ),
  'vars' => 
  array (
    'url_main' => 'main.php',
    'url_editactive' => 'editactive.php?table=',
    'url_list_admin' => 'list.php?table=admin',
    'url_create_admin' => 'edit.php?table=admin',
    'url_list_domain' => 'list.php?table=domain',
    'url_edit_domain' => 'edit.php?table=domain',
    'url_list_virtual' => 'list-virtual.php',
    'url_create_mailbox' => 'edit.php?table=mailbox',
    'url_create_alias' => 'edit.php?table=alias',
    'url_create_alias_domain' => 'edit.php?table=aliasdomain',
    'url_fetchmail' => 'list.php?table=fetchmail',
    'url_fetchmail_new_entry' => 'edit.php?table=fetchmail',
    'url_sendmail' => 'sendmail.php',
    'url_broadcast_message' => 'broadcast-message.php',
    'url_password' => 'edit.php?table=adminpassword',
    'url_backup' => 'backup.php',
    'url_viewlog' => 'viewlog.php',
    'url_logout' => 'login.php',
    'url_user_main' => 'main.php',
    'url_user_edit_alias' => 'edit-alias.php',
    'url_user_vacation' => 'vacation.php',
    'url_user_password' => 'password.php',
    'url_user_logout' => 'login.php',
    'tr_header' => '<tr class="header">',
    'tr_hilightoff' => '<tr class="hilightoff" onmouseover="className=\'hilighton\';" onmouseout="className=\'hilightoff\';">',
    'url_delete' => 'delete.php',
    'url_search' => 'list-virtual.php',
    'form_search' => '<form name="search" method="post" action="list-virtual.php"><input class="form-control" name="search[_]" size="10" /></form>',
  ),
));
}
}
