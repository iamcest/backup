<?php
/* Smarty version 3.1.33, created on 2022-01-26 00:36:24
  from '/usr/share/nginx/postfixadmin/templates/users_menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f097888e7818_72336993',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'acd9e0f9929a6f09fb9c47b4d2e106c36f301ec1' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/users_menu.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61f097888e7818_72336993 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
                        <a class="navbar-brand" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_main');?>
"><img id="login_header_logo"
                                                                                   src="../images/postbox.png"
                                                                                   alt="Logo"/></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_main');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_main'];?>
</a></li>
                <?php if ($_smarty_tpl->tpl_vars['CONF']->value['vacation'] === 'YES') {?>
                    <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_vacation');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_vacation'];?>
</a></li>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['CONF']->value['edit_alias'] === 'YES') {?>
                    <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_edit_alias');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_edit_alias'];?>
</a></li>
                <?php }?>
                <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_password');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
</a></li>
                <li class="logout"><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_logout');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_logout'];?>
</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php }
}
