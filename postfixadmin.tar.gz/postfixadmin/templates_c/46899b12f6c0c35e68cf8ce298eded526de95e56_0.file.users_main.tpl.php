<?php
/* Smarty version 3.1.33, created on 2022-01-26 00:36:24
  from '/usr/share/nginx/postfixadmin/templates/users_main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_61f097888f1406_96352772',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '46899b12f6c0c35e68cf8ce298eded526de95e56' => 
    array (
      0 => '/usr/share/nginx/postfixadmin/templates/users_main.tpl',
      1 => 1629209300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61f097888f1406_96352772 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-default" id="main_menu">
    <table class="table">
        <?php if ($_smarty_tpl->tpl_vars['CONF']->value['vacation'] === 'YES') {?>
            <tr>
                <td nowrap="nowrap"><a class="btn btn-primary" href="vacation.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_vacation'];?>
</a>
                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['tummVacationtext']->value;?>
</td>
            </tr>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['CONF']->value['edit_alias'] === 'YES') {?>
            <tr>
                <td nowrap="nowrap"><a class="btn btn-primary" href="edit-alias.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_edit_alias'];?>
</a>
                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMain_edit_alias'];?>
</td>
            </tr>
        <?php }?>
        <tr>
            <td nowrap="nowrap"><a class="btn btn-primary" href="password.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
</a></td>
            <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMain_password'];?>
</td>
        </tr>
        <tr>
            <td nowrap="nowrap"><a class="btn btn-primary" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_logout');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_logout'];?>
</a></td>
            <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMain_logout'];?>
</td>
        </tr>
    </table>
</div>
<?php }
}
