<?php
$CONF['configured'] = true;
$CONF['database_type'] = 'mysqli';
$CONF['database_host'] = 'localhost';
$CONF['database_port'] = '3306';
$CONF['database_user'] = 'postfixadmin';
$CONF['database_password'] = 'Postfixadmin&2022';
$CONF['database_name'] = 'postfixadmin';
$CONF['encrypt'] = 'md5crypt';
$CONF['dovecotpw'] = "/usr/bin/doveadm pw -r 12";
$CONF['setup_password'] = '$2y$10$WqJ.tn88mqdrKWy6nkq7o.gfq2x5e/J4ig//oHygbzqDf0k00f6Gu';
