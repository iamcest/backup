Random Screenshots taken on 2007/09/25, using a version of Postfixadmin from subversion.

