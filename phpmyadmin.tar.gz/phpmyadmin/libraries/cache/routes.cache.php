<?php return array (
  0 => 
  array (
    'GET' => 
    array (
      '' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'index',
      ),
      '/' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'index',
      ),
      '/recent-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'reloadRecentTablesList',
      ),
      '/git-revision' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'gitRevision',
      ),
      '/browse-foreigners' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\BrowseForeignersController',
        1 => 'index',
      ),
      '/changelog' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ChangeLogController',
        1 => 'index',
      ),
      '/check-relations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\CheckRelationsController',
        1 => 'index',
      ),
      '/database/central-columns' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\CentralColumnsController',
        1 => 'index',
      ),
      '/database/data-dictionary' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\DataDictionaryController',
        1 => 'index',
      ),
      '/database/designer' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\DesignerController',
        1 => 'index',
      ),
      '/database/events' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\EventsController',
        1 => 'index',
      ),
      '/database/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\ExportController',
        1 => 'index',
      ),
      '/database/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\ImportController',
        1 => 'index',
      ),
      '/database/multi-table-query' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\MultiTableQueryController',
        1 => 'index',
      ),
      '/database/multi-table-query/tables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\MultiTableQueryController',
        1 => 'table',
      ),
      '/database/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\OperationsController',
        1 => 'index',
      ),
      '/database/qbe' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\QueryByExampleController',
        1 => 'index',
      ),
      '/database/routines' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\RoutinesController',
        1 => 'index',
      ),
      '/database/search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SearchController',
        1 => 'index',
      ),
      '/database/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SqlController',
        1 => 'index',
      ),
      '/database/structure' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'index',
      ),
      '/database/structure/favorite-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'addRemoveFavoriteTablesAction',
      ),
      '/database/structure/real-row-count' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'handleRealRowCountRequestAction',
      ),
      '/database/tracking' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\TrackingController',
        1 => 'index',
      ),
      '/database/triggers' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\TriggersController',
        1 => 'index',
      ),
      '/error-report' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ErrorReportController',
        1 => 'index',
      ),
      '/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportController',
        1 => 'index',
      ),
      '/export/check-time-out' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportController',
        1 => 'checkTimeOut',
      ),
      '/gis-data-editor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\GisDataEditorController',
        1 => 'index',
      ),
      '/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ImportController',
        1 => 'index',
      ),
      '/import-status' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ImportStatusController',
        1 => 'index',
      ),
      '/license' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\LicenseController',
        1 => 'index',
      ),
      '/lint' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\LintController',
        1 => 'index',
      ),
      '/logout' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\LogoutController',
        1 => 'index',
      ),
      '/navigation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\NavigationController',
        1 => 'index',
      ),
      '/normalization' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\NormalizationController',
        1 => 'index',
      ),
      '/phpinfo' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\PhpInfoController',
        1 => 'index',
      ),
      '/preferences/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ExportController',
        1 => 'index',
      ),
      '/preferences/features' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\FeaturesController',
        1 => 'index',
      ),
      '/preferences/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ImportController',
        1 => 'index',
      ),
      '/preferences/main-panel' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\MainPanelController',
        1 => 'index',
      ),
      '/preferences/manage' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ManageController',
        1 => 'index',
      ),
      '/preferences/navigation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\NavigationController',
        1 => 'index',
      ),
      '/preferences/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\SqlController',
        1 => 'index',
      ),
      '/preferences/two-factor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\TwoFactorController',
        1 => 'index',
      ),
      '/schema-export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SchemaExportController',
        1 => 'index',
      ),
      '/server/binlog' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\BinlogController',
        1 => 'index',
      ),
      '/server/collations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\CollationsController',
        1 => 'index',
      ),
      '/server/databases' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\DatabasesController',
        1 => 'index',
      ),
      '/server/engines' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\EnginesController',
        1 => 'index',
      ),
      '/server/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ExportController',
        1 => 'index',
      ),
      '/server/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ImportController',
        1 => 'index',
      ),
      '/server/plugins' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\PluginsController',
        1 => 'index',
      ),
      '/server/privileges' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\PrivilegesController',
        1 => 'index',
      ),
      '/server/replication' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ReplicationController',
        1 => 'index',
      ),
      '/server/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\SqlController',
        1 => 'index',
      ),
      '/server/status' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\StatusController',
        1 => 'index',
      ),
      '/server/status/advisor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\AdvisorController',
        1 => 'index',
      ),
      '/server/status/monitor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'index',
      ),
      '/server/status/processes' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\ProcessesController',
        1 => 'index',
      ),
      '/server/status/queries' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\QueriesController',
        1 => 'index',
      ),
      '/server/status/variables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\VariablesController',
        1 => 'index',
      ),
      '/server/user-groups' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\UserGroupsController',
        1 => 'index',
      ),
      '/server/variables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\VariablesController',
        1 => 'index',
      ),
      '/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'index',
      ),
      '/sql/get-default-fk-check-value' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'getDefaultForeignKeyCheckValue',
      ),
      '/table/add-field' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\AddFieldController',
        1 => 'index',
      ),
      '/table/change' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ChangeController',
        1 => 'index',
      ),
      '/table/chart' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ChartController',
        1 => 'index',
      ),
      '/table/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\CreateController',
        1 => 'index',
      ),
      '/table/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ExportController',
        1 => 'index',
      ),
      '/table/find-replace' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\FindReplaceController',
        1 => 'index',
      ),
      '/table/get-field' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\GetFieldController',
        1 => 'index',
      ),
      '/table/gis-visualization' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\GisVisualizationController',
        1 => 'index',
      ),
      '/table/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ImportController',
        1 => 'index',
      ),
      '/table/indexes' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\IndexesController',
        1 => 'index',
      ),
      '/table/indexes/rename' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\IndexesController',
        1 => 'indexRename',
      ),
      '/table/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\OperationsController',
        1 => 'index',
      ),
      '/table/recent-favorite' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\RecentFavoriteController',
        1 => 'index',
      ),
      '/table/relation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\RelationController',
        1 => 'index',
      ),
      '/table/replace' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ReplaceController',
        1 => 'index',
      ),
      '/table/search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\SearchController',
        1 => 'index',
      ),
      '/table/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\SqlController',
        1 => 'index',
      ),
      '/table/structure' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'index',
      ),
      '/table/structure/change' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'change',
      ),
      '/table/tracking' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\TrackingController',
        1 => 'index',
      ),
      '/table/triggers' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\TriggersController',
        1 => 'index',
      ),
      '/table/zoom-search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ZoomSearchController',
        1 => 'index',
      ),
      '/themes' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ThemesController',
        1 => 'index',
      ),
      '/transformation/overview' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\TransformationOverviewController',
        1 => 'index',
      ),
      '/transformation/wrapper' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\TransformationWrapperController',
        1 => 'index',
      ),
      '/user-password' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\UserPasswordController',
        1 => 'index',
      ),
      '/version-check' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\VersionCheckController',
        1 => 'index',
      ),
      '/view/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ViewCreateController',
        1 => 'index',
      ),
      '/view/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ViewOperationsController',
        1 => 'index',
      ),
    ),
    'POST' => 
    array (
      '' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'index',
      ),
      '/' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'index',
      ),
      '/set-theme' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'setTheme',
      ),
      '/collation-connection' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'setCollationConnection',
      ),
      '/recent-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'reloadRecentTablesList',
      ),
      '/git-revision' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\HomeController',
        1 => 'gitRevision',
      ),
      '/browse-foreigners' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\BrowseForeignersController',
        1 => 'index',
      ),
      '/check-relations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\CheckRelationsController',
        1 => 'index',
      ),
      '/columns' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ColumnController',
        1 => 'all',
      ),
      '/config/get' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ConfigController',
        1 => 'get',
      ),
      '/config/set' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ConfigController',
        1 => 'set',
      ),
      '/database/central-columns' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\CentralColumnsController',
        1 => 'index',
      ),
      '/database/central-columns/populate' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\CentralColumnsController',
        1 => 'populateColumns',
      ),
      '/database/designer' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\DesignerController',
        1 => 'index',
      ),
      '/database/events' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\EventsController',
        1 => 'index',
      ),
      '/database/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\ExportController',
        1 => 'index',
      ),
      '/database/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\ImportController',
        1 => 'index',
      ),
      '/database/multi-table-query/query' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\MultiTableQueryController',
        1 => 'displayResults',
      ),
      '/database/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\OperationsController',
        1 => 'index',
      ),
      '/database/operations/collation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\OperationsController',
        1 => 'collation',
      ),
      '/database/qbe' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\QueryByExampleController',
        1 => 'index',
      ),
      '/database/routines' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\RoutinesController',
        1 => 'index',
      ),
      '/database/search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SearchController',
        1 => 'index',
      ),
      '/database/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SqlController',
        1 => 'index',
      ),
      '/database/sql/autocomplete' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SqlAutoCompleteController',
        1 => 'index',
      ),
      '/database/sql/format' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\SqlFormatController',
        1 => 'index',
      ),
      '/database/structure' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'index',
      ),
      '/database/structure/add-prefix' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'addPrefix',
      ),
      '/database/structure/add-prefix-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'addPrefixTable',
      ),
      '/database/structure/central-columns-add' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'centralColumnsAdd',
      ),
      '/database/structure/central-columns-make-consistent' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'centralColumnsMakeConsistent',
      ),
      '/database/structure/central-columns-remove' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'centralColumnsRemove',
      ),
      '/database/structure/change-prefix-form' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'changePrefixForm',
      ),
      '/database/structure/copy-form' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'copyForm',
      ),
      '/database/structure/copy-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'copyTable',
      ),
      '/database/structure/copy-table-with-prefix' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'copyTableWithPrefix',
      ),
      '/database/structure/drop-form' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'dropForm',
      ),
      '/database/structure/drop-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'dropTable',
      ),
      '/database/structure/empty-form' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'emptyForm',
      ),
      '/database/structure/empty-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'emptyTable',
      ),
      '/database/structure/favorite-table' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'addRemoveFavoriteTablesAction',
      ),
      '/database/structure/real-row-count' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'handleRealRowCountRequestAction',
      ),
      '/database/structure/replace-prefix' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'replacePrefix',
      ),
      '/database/structure/show-create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\StructureController',
        1 => 'showCreate',
      ),
      '/database/tracking' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\TrackingController',
        1 => 'index',
      ),
      '/database/triggers' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\TriggersController',
        1 => 'index',
      ),
      '/databases' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\DatabaseController',
        1 => 'all',
      ),
      '/error-report' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ErrorReportController',
        1 => 'index',
      ),
      '/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportController',
        1 => 'index',
      ),
      '/export/tables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Database\\ExportController',
        1 => 'tables',
      ),
      '/export/template/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportTemplateController',
        1 => 'create',
      ),
      '/export/template/delete' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportTemplateController',
        1 => 'delete',
      ),
      '/export/template/load' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportTemplateController',
        1 => 'load',
      ),
      '/export/template/update' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ExportTemplateController',
        1 => 'update',
      ),
      '/gis-data-editor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\GisDataEditorController',
        1 => 'index',
      ),
      '/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ImportController',
        1 => 'index',
      ),
      '/import-status' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ImportStatusController',
        1 => 'index',
      ),
      '/lint' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\LintController',
        1 => 'index',
      ),
      '/logout' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\LogoutController',
        1 => 'index',
      ),
      '/navigation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\NavigationController',
        1 => 'index',
      ),
      '/normalization' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\NormalizationController',
        1 => 'index',
      ),
      '/preferences/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ExportController',
        1 => 'index',
      ),
      '/preferences/features' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\FeaturesController',
        1 => 'index',
      ),
      '/preferences/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ImportController',
        1 => 'index',
      ),
      '/preferences/main-panel' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\MainPanelController',
        1 => 'index',
      ),
      '/preferences/manage' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\ManageController',
        1 => 'index',
      ),
      '/preferences/navigation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\NavigationController',
        1 => 'index',
      ),
      '/preferences/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\SqlController',
        1 => 'index',
      ),
      '/preferences/two-factor' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Preferences\\TwoFactorController',
        1 => 'index',
      ),
      '/schema-export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SchemaExportController',
        1 => 'index',
      ),
      '/server/binlog' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\BinlogController',
        1 => 'index',
      ),
      '/server/databases' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\DatabasesController',
        1 => 'index',
      ),
      '/server/databases/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\DatabasesController',
        1 => 'create',
      ),
      '/server/databases/destroy' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\DatabasesController',
        1 => 'destroy',
      ),
      '/server/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ExportController',
        1 => 'index',
      ),
      '/server/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ImportController',
        1 => 'index',
      ),
      '/server/privileges' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\PrivilegesController',
        1 => 'index',
      ),
      '/server/replication' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\ReplicationController',
        1 => 'index',
      ),
      '/server/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\SqlController',
        1 => 'index',
      ),
      '/server/status/monitor/chart' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'chartingData',
      ),
      '/server/status/monitor/slow-log' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'logDataTypeSlow',
      ),
      '/server/status/monitor/general-log' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'logDataTypeGeneral',
      ),
      '/server/status/monitor/log-vars' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'loggingVars',
      ),
      '/server/status/monitor/query' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\MonitorController',
        1 => 'queryAnalyzer',
      ),
      '/server/status/processes' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\ProcessesController',
        1 => 'index',
      ),
      '/server/status/processes/refresh' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\ProcessesController',
        1 => 'refresh',
      ),
      '/server/status/variables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\VariablesController',
        1 => 'index',
      ),
      '/server/user-groups' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Server\\UserGroupsController',
        1 => 'index',
      ),
      '/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'index',
      ),
      '/sql/get-relational-values' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'getRelationalValues',
      ),
      '/sql/get-enum-values' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'getEnumValues',
      ),
      '/sql/get-set-values' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'getSetValues',
      ),
      '/sql/set-column-preferences' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\SqlController',
        1 => 'setColumnOrderOrVisibility',
      ),
      '/table/add-field' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\AddFieldController',
        1 => 'index',
      ),
      '/table/change' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ChangeController',
        1 => 'index',
      ),
      '/table/change/rows' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ChangeController',
        1 => 'rows',
      ),
      '/table/chart' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ChartController',
        1 => 'index',
      ),
      '/table/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\CreateController',
        1 => 'index',
      ),
      '/table/delete/confirm' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\DeleteController',
        1 => 'confirm',
      ),
      '/table/delete/rows' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\DeleteController',
        1 => 'rows',
      ),
      '/table/export' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ExportController',
        1 => 'index',
      ),
      '/table/export/rows' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ExportController',
        1 => 'rows',
      ),
      '/table/find-replace' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\FindReplaceController',
        1 => 'index',
      ),
      '/table/get-field' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\GetFieldController',
        1 => 'index',
      ),
      '/table/gis-visualization' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\GisVisualizationController',
        1 => 'index',
      ),
      '/table/import' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ImportController',
        1 => 'index',
      ),
      '/table/indexes' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\IndexesController',
        1 => 'index',
      ),
      '/table/indexes/rename' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\IndexesController',
        1 => 'indexRename',
      ),
      '/table/maintenance/analyze' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\MaintenanceController',
        1 => 'analyze',
      ),
      '/table/maintenance/check' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\MaintenanceController',
        1 => 'check',
      ),
      '/table/maintenance/checksum' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\MaintenanceController',
        1 => 'checksum',
      ),
      '/table/maintenance/optimize' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\MaintenanceController',
        1 => 'optimize',
      ),
      '/table/maintenance/repair' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\MaintenanceController',
        1 => 'repair',
      ),
      '/table/partition/analyze' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'analyze',
      ),
      '/table/partition/check' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'check',
      ),
      '/table/partition/drop' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'drop',
      ),
      '/table/partition/optimize' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'optimize',
      ),
      '/table/partition/rebuild' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'rebuild',
      ),
      '/table/partition/repair' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'repair',
      ),
      '/table/partition/truncate' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\PartitionController',
        1 => 'truncate',
      ),
      '/table/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\OperationsController',
        1 => 'index',
      ),
      '/table/recent-favorite' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\RecentFavoriteController',
        1 => 'index',
      ),
      '/table/relation' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\RelationController',
        1 => 'index',
      ),
      '/table/replace' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ReplaceController',
        1 => 'index',
      ),
      '/table/search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\SearchController',
        1 => 'index',
      ),
      '/table/sql' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\SqlController',
        1 => 'index',
      ),
      '/table/structure' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'index',
      ),
      '/table/structure/add-key' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'addKey',
      ),
      '/table/structure/browse' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'browse',
      ),
      '/table/structure/central-columns-add' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'addToCentralColumns',
      ),
      '/table/structure/central-columns-remove' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'removeFromCentralColumns',
      ),
      '/table/structure/change' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'change',
      ),
      '/table/structure/drop' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'drop',
      ),
      '/table/structure/drop-confirm' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'dropConfirm',
      ),
      '/table/structure/fulltext' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'fulltext',
      ),
      '/table/structure/index' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'addIndex',
      ),
      '/table/structure/move-columns' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'moveColumns',
      ),
      '/table/structure/partitioning' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'partitioning',
      ),
      '/table/structure/primary' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'primary',
      ),
      '/table/structure/reserved-word-check' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'reservedWordCheck',
      ),
      '/table/structure/save' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'save',
      ),
      '/table/structure/spatial' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'spatial',
      ),
      '/table/structure/unique' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\StructureController',
        1 => 'unique',
      ),
      '/table/tracking' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\TrackingController',
        1 => 'index',
      ),
      '/table/triggers' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\TriggersController',
        1 => 'index',
      ),
      '/table/zoom-search' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\Table\\ZoomSearchController',
        1 => 'index',
      ),
      '/tables' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\TableController',
        1 => 'all',
      ),
      '/transformation/overview' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\TransformationOverviewController',
        1 => 'index',
      ),
      '/transformation/wrapper' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\TransformationWrapperController',
        1 => 'index',
      ),
      '/user-password' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\UserPasswordController',
        1 => 'index',
      ),
      '/version-check' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\VersionCheckController',
        1 => 'index',
      ),
      '/view/create' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ViewCreateController',
        1 => 'index',
      ),
      '/view/operations' => 
      array (
        0 => 'PhpMyAdmin\\Controllers\\ViewOperationsController',
        1 => 'index',
      ),
    ),
  ),
  1 => 
  array (
    'GET' => 
    array (
      0 => 
      array (
        'regex' => '~^(?|/server/engines/([^/]+)|/server/engines/([^/]+)/([^/]+)|/server/variables/get/([^/]+)()())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 
            array (
              0 => 'PhpMyAdmin\\Controllers\\Server\\EnginesController',
              1 => 'show',
            ),
            1 => 
            array (
              'engine' => 'engine',
            ),
          ),
          3 => 
          array (
            0 => 
            array (
              0 => 'PhpMyAdmin\\Controllers\\Server\\EnginesController',
              1 => 'show',
            ),
            1 => 
            array (
              'engine' => 'engine',
              'page' => 'page',
            ),
          ),
          4 => 
          array (
            0 => 
            array (
              0 => 'PhpMyAdmin\\Controllers\\Server\\VariablesController',
              1 => 'getValue',
            ),
            1 => 
            array (
              'name' => 'name',
            ),
          ),
        ),
      ),
    ),
    'POST' => 
    array (
      0 => 
      array (
        'regex' => '~^(?|/server/status/processes/kill/(\\d+)|/server/variables/set/([^/]+)())$~',
        'routeMap' => 
        array (
          2 => 
          array (
            0 => 
            array (
              0 => 'PhpMyAdmin\\Controllers\\Server\\Status\\ProcessesController',
              1 => 'kill',
            ),
            1 => 
            array (
              'id' => 'id',
            ),
          ),
          3 => 
          array (
            0 => 
            array (
              0 => 'PhpMyAdmin\\Controllers\\Server\\VariablesController',
              1 => 'setValue',
            ),
            1 => 
            array (
              'name' => 'name',
            ),
          ),
        ),
      ),
    ),
  ),
);